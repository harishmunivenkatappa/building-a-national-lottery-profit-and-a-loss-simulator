# urls.py
from django.urls import path
from .views import UKNationalLottoSimulatorView, RunSimulatorView, HistoricalFrequencies

urlpatterns = [
    path('', UKNationalLottoSimulatorView.as_view(), name='uk_national_lotto_simulator'),
    path('run-simulator/', RunSimulatorView.as_view(), name='run_simulation'),
    path('uk-frequencies/', HistoricalFrequencies.as_view(), name='uk_frequencies'),

    # Other URL patterns...
]
