from django import template

register = template.Library()


@register.filter
def to(value):
    """Generates a range object from 1 to value."""
    return range(1, value + 1)
