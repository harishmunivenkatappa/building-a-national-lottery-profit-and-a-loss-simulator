import random
import json
import time
from collections import Counter

from django.views import View
from django.views.generic.edit import FormView
from django import forms
from django.urls import reverse_lazy
from django.http import JsonResponse


from .algorithms import MonteCarloSimulator, HistoricalBasedSimulator
from accounts.models import SimulationHistory

from accounts.models import UKNationalDrawHistory


class LottoForm(forms.Form):
    numbers = forms.CharField(
        label='Enter your numbers (separated by commas):',
        widget=forms.TextInput(attrs={'placeholder': 'e.g., 1, 2, 3, 4, 5, 6'}),
    )


class UKNationalLottoSimulatorView(FormView):
    template_name = 'uk_lottery_simulator.html'
    form_class = LottoForm
    success_url = reverse_lazy('uk_national_lotto_simulator')

    def form_valid(self, form):
        numbers = form.cleaned_data['numbers']
        user_numbers = list(map(int, numbers.split(',')))
        draw_numbers = sorted(random.sample(range(1, 60), 6))
        matches = len(set(user_numbers) & set(draw_numbers))
        context = self.get_context_data()
        context['results'] = {
            'user_numbers': user_numbers,
            'draw_numbers': draw_numbers,
            'matches': matches
        }
        return self.render_to_response(context)

class RunSimulatorView(View):
    def post(self, request, *args, **kwargs):
        try:
            # Parse the request body
            body = json.loads(request.body)
            user_numbers = [int(a) for a in body['numbers'].split(',')]
            # Extract parameters from the JSON body
            algorithm = body.get('algorithm', '').lower()
            # import pdb;pdb.set_trace()
            num_years= int(body.get('numYears', 1000000))
            weekly_draw = int(body.get('weeklyDraws', 1))
            n_weeks =  365//7
            simulations = n_weeks * weekly_draw * num_years
            # Determine the algorithm and run the appropriate simulation
            start = time.time()
            if algorithm == "monte-carlo":
                simulator = MonteCarloSimulator(user_numbers, simulations)
            else:
                algorithm = "History Based Weighted Average"
                historical_draws = UKNationalDrawHistory.objects.all()
                history = [[
                draw.ball_1, draw.ball_2, draw.ball_3,
                draw.ball_4, draw.ball_5, draw.ball_6
            ] for draw in historical_draws]
                simulator = HistoricalBasedSimulator(user_numbers, simulations,history)

            response_data= simulator.monte_carlo_simulation()
            end = time.time()
            time_taken = end-start
            # Store the simulation data if the user is logged in
            if request.user.is_authenticated:
                print("storing history")
                SimulationHistory.objects.create(
                    user=request.user,
                    probabilities=response_data.get('probabilities', {}),
                    expected_return=response_data.get('expected_return', 0.0),
                    total_investment=response_data.get('total_investment', 0.0),
                    total_earning=response_data.get('total_earning', 0.0),
                    balance=response_data.get('balance', 0.0),
                    user_number=', '.join(map(str, user_numbers)),
                    time_taken=time_taken,
                    num_of_simulations=simulations,
                    num_of_years=num_years,
                    weekly_draws=weekly_draw,
                    algorithm=algorithm,
                )

        except (json.JSONDecodeError, ValueError):
            response_data = {
                "error": "Invalid input data. Please provide valid JSON."
            }

        # Return the response as JSON
        print(response_data)
        return JsonResponse(response_data)

class HistoricalFrequencies(View):
    def get(self, request, *args, **kwargs):
        # Query all draws
        all_draws = UKNationalDrawHistory.objects.all()

        # Initialize lists to store main balls and lucky stars
        main_balls = []

        # Iterate through each draw and add balls to the appropriate list
        for draw in all_draws:
            main_balls.extend([draw.ball_1, draw.ball_2, draw.ball_3, draw.ball_4, draw.ball_5, draw.ball_6])

        # Calculate the frequency using Counter from the collections module
        main_ball_frequencies = dict(Counter(main_balls))


        # Create a dictionary to store the result
        frequency_data = {
            "main_ball_frequencies": main_ball_frequencies,
        }

        # Return the data as a JSON response
        return JsonResponse(frequency_data)
