# lotterysimulator

## RUNNING THE SIMULATOR

- First install the requirements listed in requirements.txt file using command:
  - **pip install -r requirements.txt**
  - then change directory to enter LotterySimulator where manage.py is present.
  - Then in that directory type command in terminal: *python manage.py runserver*