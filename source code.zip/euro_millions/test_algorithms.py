import unittest
from unittest.mock import patch
import random

from LotterySimulator.euro_millions.algorithms import MonteCarloSimulator


class TestMonteCarloSimulator(unittest.TestCase):

    def setUp(self):
        # Test with a known set of user numbers and lucky stars
        self.simulator = MonteCarloSimulator(user_main_numbers=[1, 2, 3, 4, 5], user_lucky_stars=[1, 2],
                                             simulations=10000)

    def test_draw_lotto(self):
        """Test that the draw_lotto method generates valid results."""
        main_numbers, lucky_stars = self.simulator.draw_lotto()

        # Check that 5 main numbers are drawn and are between 1 and 50
        self.assertEqual(len(main_numbers), 5)
        for number in main_numbers:
            self.assertIn(number, MonteCarloSimulator.MAIN_NUMBERS_POOL)

        # Check that 2 lucky stars are drawn and are between 1 and 12
        self.assertEqual(len(lucky_stars), 2)
        for star in lucky_stars:
            self.assertIn(star, MonteCarloSimulator.LUCKY_STARS_POOL)

    def test_generate_ticket(self):
        """Test that the ticket generation matches the user's numbers."""
        ticket = self.simulator.generate_ticket()
        self.assertEqual(ticket[0], [1, 2, 3, 4, 5])
        self.assertEqual(ticket[1], [1, 2])

    def test_determine_prize(self):
        """Test the prize determination logic with different outcomes."""
        # Create a mock ticket and mock draw results
        ticket = ([1, 2, 3, 4, 5], [1, 2])

        # Test for Jackpot (5 main + 2 stars)
        draw_results = ([1, 2, 3, 4, 5], [1, 2])
        prize = self.simulator.determine_prize(ticket, draw_results)
        self.assertEqual(prize, "Jackpot")

        # Test for Match 5 + 1 Lucky Star
        draw_results = ([1, 2, 3, 4, 5], [1, 3])
        prize = self.simulator.determine_prize(ticket, draw_results)
        self.assertEqual(prize, "Match 5 + 1 Lucky Star")

        # Test for Match 4 + 2 Lucky Stars
        draw_results = ([1, 2, 3, 4, 6], [1, 2])
        prize = self.simulator.determine_prize(ticket, draw_results)
        self.assertEqual(prize, "Match 4 + 2 Lucky Stars")

        # Test for Match 3 (no stars)
        draw_results = ([1, 2, 3, 7, 8], [9, 10])
        prize = self.simulator.determine_prize(ticket, draw_results)
        self.assertEqual(prize, "Match 3")

        # Test for No Win
        draw_results = ([10, 20, 30, 40, 50], [9, 12])
        prize = self.simulator.determine_prize(ticket, draw_results)
        self.assertEqual(prize, "No Win")

    @patch('random.sample')
    def test_simulate_single_process(self, mock_sample):
        """Test the simulate_single_process method."""
        # Mock the random.sample to return specific values for testing
        mock_sample.side_effect = [
            [1, 2, 3, 4, 5], [1, 2],  # First draw - Jackpot
            [1, 2, 3, 4, 5], [1, 3],  # Second draw - Match 5 + 1 Lucky Star
        ]

        outcomes = self.simulator.simulate_single_process(2)

        # Check the outcomes are as expected
        self.assertEqual(outcomes["Jackpot"], 1)
        self.assertEqual(outcomes["Match 5 + 1 Lucky Star"], 1)
        self.assertEqual(outcomes["No Win"], 0)

    @patch.object(MonteCarloSimulator, 'draw_lotto')
    def test_monte_carlo_simulation(self, mock_draw_lotto):
        """Test the monte_carlo_simulation method with mocked draws."""
        # Mock the draw_lotto to return specific results for consistent testing
        mock_draw_lotto.side_effect = [
            ([1, 2, 3, 4, 5], [1, 2]),  # Jackpot
            ([1, 2, 3, 4, 5], [1, 3]),  # Match 5 + 1 Lucky Star
        ]

        # Run the simulation for 2 simulations
        simulator = MonteCarloSimulator(user_main_numbers=[1, 2, 3, 4, 5], user_lucky_stars=[1, 2], simulations=2)
        result = simulator.monte_carlo_simulation()

        # Check the probability of Jackpot is 50% (1 out of 2)
        self.assertAlmostEqual(result["probabilities"]["Jackpot"], 0.5)
        self.assertAlmostEqual(result["probabilities"]["Match 5 + 1 Lucky Star"], 0.5)
        self.assertEqual(result["probabilities"]["No Win"], 0)

        # Check expected return and balance calculations
        expected_return = 0.5 * 17000000 + 0.5 * 500000
        total_investment = 2 * simulator.ticket_cost
        total_earning = expected_return * 2
        balance = total_earning - total_investment

        self.assertAlmostEqual(result["expected_return"], expected_return)
        self.assertAlmostEqual(result["total_investment"], total_investment)
        self.assertAlmostEqual(result["total_earning"], total_earning)
        self.assertAlmostEqual(result["balance"], balance)


if __name__ == '__main__':
    unittest.main()
