import random
import json
import time
from collections import Counter

from django.views import View
from django.views.generic.edit import FormView
from django import forms
from django.urls import reverse_lazy
from django.http import JsonResponse

from .algorithms import MonteCarloSimulator, HistoryBasedSimulator
from accounts.models import SimulationHistory

from accounts.models import EuroMillionsDraw


class LottoForm(forms.Form):
    numbers = forms.CharField(
        label='Enter your numbers (separated by commas):',
        widget=forms.TextInput(attrs={'placeholder': 'e.g., 1, 2, 3, 4, 5, 6'}),
    )


class EuroMillionLotterySimulatorView(FormView):
    template_name = 'euro_million_simulator.html'
    form_class = LottoForm
    success_url = reverse_lazy('euro_million_simulator')

    def form_valid(self, form):
        numbers = form.cleaned_data['numbers']
        user_numbers = list(map(int, numbers.split(',')))
        draw_numbers = sorted(random.sample(range(1, 60), 6))
        matches = len(set(user_numbers) & set(draw_numbers))
        context = self.get_context_data()
        context['results'] = {
            'user_numbers': user_numbers,
            'draw_numbers': draw_numbers,
            'matches': matches
        }
        return self.render_to_response(context)


class RunSimulatorView(View):
    def post(self, request, *args, **kwargs):
        try:
            # Parse the request body
            body = json.loads(request.body)
            user_numbers = [int(a) for a in body['mainNumbers'].split(',')]
            lucky_stars = [int(a) for a in body['luckyStars'].split(',')]
            # Extract parameters from the JSON body
            algorithm = body.get('algorithm', '').lower()
            num_years = int(body.get('numYears', 1000000))
            weekly_draw = int(body.get('weeklyDraws', 1))
            n_weeks = 365 // 7
            simulations = n_weeks * weekly_draw * num_years
            # Determine the algorithm and run the appropriate simulation
            # Initialize the simulator
            start = time.time()
            if algorithm == "monte-carlo":
                simulator = MonteCarloSimulator(user_numbers, lucky_stars, simulations)
            else:
                algorithm = "History Based Weighted Average"
                historical_draws = EuroMillionsDraw.objects.all()
                historical_numbers = [[
                    draw.ball_1, draw.ball_2, draw.ball_3, draw.ball_4, draw.ball_5
                ] for draw in historical_draws]
                historical_lucky_stars = [[draw.lucky_star_1, draw.lucky_star_2] for draw in historical_draws]
                simulator = HistoryBasedSimulator(user_numbers, lucky_stars, simulations, historical_numbers,
                                                  historical_lucky_stars)
            response_data = simulator.monte_carlo_simulation()
            end = time.time()
            time_taken = end - start
            if request.user.is_authenticated:
                print("storing history")
                SimulationHistory.objects.create(
                    user=request.user,
                    probabilities=response_data.get('probabilities', {}),
                    expected_return=response_data.get('expected_return', 0.0),
                    total_investment=response_data.get('total_investment', 0.0),
                    total_earning=response_data.get('total_earning', 0.0),
                    balance=response_data.get('balance', 0.0),
                    user_number=', '.join(map(str, user_numbers)),
                    time_taken=time_taken,
                    lottery_type='EURO_MILLIONS',
                    num_of_simulations=simulations,
                    num_of_years=num_years,
                    weekly_draws=weekly_draw,
                    algorithm=algorithm
                )

        except (json.JSONDecodeError, ValueError):
            response_data = {
                "error": "Invalid input data. Please provide valid JSON."
            }

        # Return the response as JSON
        print(response_data)
        return JsonResponse(response_data)


class EuroMillionsFrequencyView(View):
    """
    A view that returns the frequency of each main ball and lucky star
    from the EuroMillions draws in dictionary format.
    """

    def get(self, request, *args, **kwargs):
        # Query all draws
        all_draws = EuroMillionsDraw.objects.all()

        # Initialize lists to store main balls and lucky stars
        main_balls = []
        lucky_stars = []

        # Iterate through each draw and add balls to the appropriate list
        for draw in all_draws:
            main_balls.extend([draw.ball_1, draw.ball_2, draw.ball_3, draw.ball_4, draw.ball_5])
            lucky_stars.extend([draw.lucky_star_1, draw.lucky_star_2])

        # Calculate the frequency using Counter from the collections module
        main_ball_frequencies = dict(Counter(main_balls))
        lucky_star_frequencies = dict(Counter(lucky_stars))

        # Create a dictionary to store the result
        frequency_data = {
            "main_ball_frequencies": main_ball_frequencies,
            "lucky_star_frequencies": lucky_star_frequencies
        }

        # Return the data as a JSON response
        return JsonResponse(frequency_data)
