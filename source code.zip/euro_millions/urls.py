# urls.py
from django.urls import path
from .views import RunSimulatorView, EuroMillionLotterySimulatorView, EuroMillionsFrequencyView

urlpatterns = [
    path('', EuroMillionLotterySimulatorView.as_view(), name='euro_million_simulator'),
    path('run-simulator/', RunSimulatorView.as_view(), name='run_simulation_euro'),
    path('frequency/', EuroMillionsFrequencyView.as_view(), name='euromillions_frequency'),
]
