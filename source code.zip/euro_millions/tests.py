class Simulator:
    NUMBERS_POOL = range(1, 60)  # Numbers from 1 to 59
    NUMBERS_DRAWN = 6  # Number of main numbers drawn
    BONUS_NUMBER = 1  # Number of bonus balls drawn

    prizes = {
        "Jackpot": 10000000,  # Example jackpot
        "Match 5 + Bonus": 50000,
        "Match 5": 1000,
        "Match 4": 100,
        "Match 3": 25,
        "Match 2": 0,  # Free play not counted in monetary value
        "No Win": 0
    }

    def __init__(self, user_number, simulations):
        self.simulations = simulations
        self.user_number = sorted(user_number)  # Ensure the user number is sorted
        self.ticket_cost = 2

    @staticmethod
    def draw_lotto():
        """Simulates a lottery draw."""
        main_numbers = sorted(random.sample(Simulator.NUMBERS_POOL, Simulator.NUMBERS_DRAWN))
        remaining_numbers = [n for n in Simulator.NUMBERS_POOL if n not in main_numbers]
        bonus_number = random.choice(remaining_numbers)
        return main_numbers, bonus_number

    def generate_ticket(self):
        """Generates a lottery ticket."""
        return self.user_number

    def determine_prize(self, ticket, draw_results):
        """Determines the prize based on the ticket and draw results."""
        main_numbers, bonus_number = draw_results
        matched_main = len(set(ticket) & set(main_numbers))
        won_bonus = bonus_number in ticket

        if matched_main == 6:
            return "Jackpot"
        elif matched_main == 5 and won_bonus:
            return "Match 5 + Bonus"
        elif matched_main == 5:
            return "Match 5"
        elif matched_main == 4:
            return "Match 4"
        elif matched_main == 3:
            return "Match 3"
        elif matched_main == 2:
            return "Match 2"
        else:
            return "No Win"

    def simulate_single_process(self, num_simulations):
        """Simulates the lottery for a single process."""
        outcomes = {key: 0 for key in self.prizes.keys()}
        ticket = self.generate_ticket()
        for _ in range(num_simulations):
            draw_results = self.draw_lotto()
            outcome = self.determine_prize(ticket, draw_results)
            outcomes[outcome] += 1

        return outcomes

    @staticmethod
    def merge_results(results_list):
        """Merges the results from multiple processes."""
        final_outcomes = {key: 0 for key in Simulator.prizes.keys()}

        for result in results_list:
            for key in result:
                final_outcomes[key] += result[key]

        return final_outcomes

    def run_simulation(self):
        """Runs the Monte Carlo simulation using parallel processing."""
        cpu_count = multiprocessing.cpu_count()
        pool = multiprocessing.Pool(cpu_count)

        simulations_per_process = self.simulations // cpu_count
        simulations_split = [simulations_per_process] * cpu_count

        # Handle any leftover simulations
        extra_simulations = self.simulations % cpu_count
        for i in range(extra_simulations):
            simulations_split[i] += 1

        results = pool.starmap(self.simulate_single_process, [(simulations,) for simulations in simulations_split])
        pool.close()
        pool.join()

        outcomes = self.merge_results(results)

        # Calculate probabilities
        probabilities = {key: outcomes[key] / self.simulations for key in outcomes}

        # Expected return per ticket
        expected_return = sum(probabilities[key] * self.prizes[key] for key in self.prizes)

        # Total investment, total earnings, and balance
        total_investment = self.simulations * self.ticket_cost
        total_earning = expected_return * self.simulations
        balance = total_earning - total_investment

        return {
            "probabilities": probabilities,
            "expected_return": expected_return,
            "total_investment": total_investment,
            "total_earning": total_earning,
            "balance": balance
        }


from django.test import TestCase

# Create your tests here.
