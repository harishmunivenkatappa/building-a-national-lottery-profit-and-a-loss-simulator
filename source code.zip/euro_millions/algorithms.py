import random
import multiprocessing
from collections import Counter


class MonteCarloSimulator:
    MAIN_NUMBERS_POOL = range(1, 51)  # Numbers from 1 to 50
    MAIN_NUMBERS_DRAWN = 5  # Number of main numbers drawn
    LUCKY_STARS_POOL = range(1, 13)  # Lucky Stars from 1 to 12
    LUCKY_STARS_DRAWN = 2  # Number of Lucky Stars drawn

    prizes = {
        "Jackpot": 17000000,  # Starting example jackpot
        "Match 5 + 2 Lucky Stars": 17000000,  # Typically same as Jackpot
        "Match 5 + 1 Lucky Star": 500000,
        "Match 5": 100000,
        "Match 4 + 2 Lucky Stars": 5000,
        "Match 4 + 1 Lucky Star": 500,
        "Match 4": 100,
        "Match 3 + 2 Lucky Stars": 50,
        "Match 3 + 1 Lucky Star": 20,
        "Match 3": 10,
        "Match 2 + 2 Lucky Stars": 10,
        "Match 2 + 1 Lucky Star": 5,
        "Match 2": 2,
        "No Win": 0
    }

    def __init__(self, user_main_numbers, user_lucky_stars, simulations):
        self.simulations = simulations
        self.user_main_numbers = sorted(user_main_numbers)  # Ensure the user's main numbers are sorted
        self.user_lucky_stars = sorted(user_lucky_stars)  # Ensure the user's Lucky Stars are sorted
        self.ticket_cost = 2.5

    @staticmethod
    def draw_lotto():
        """Simulates a EuroMillions lottery draw."""
        main_numbers = sorted(
            random.sample(MonteCarloSimulator.MAIN_NUMBERS_POOL,
                          MonteCarloSimulator.MAIN_NUMBERS_DRAWN))
        lucky_stars = sorted(
            random.sample(MonteCarloSimulator.LUCKY_STARS_POOL,
                          MonteCarloSimulator.LUCKY_STARS_DRAWN))
        return main_numbers, lucky_stars

    def generate_ticket(self):
        """Generates a EuroMillions lottery ticket."""
        return self.user_main_numbers, self.user_lucky_stars

    def determine_prize(self, ticket, draw_results):
        """Determines the prize based on the ticket and draw results."""
        main_numbers, lucky_stars = draw_results
        matched_main = len(set(ticket[0]) & set(main_numbers))
        matched_stars = len(set(ticket[1]) & set(lucky_stars))

        if matched_main == 5 and matched_stars == 2:
            return "Jackpot"
        elif matched_main == 5 and matched_stars == 2:
            return "Match 5 + 2 Lucky Stars"
        elif matched_main == 5 and matched_stars == 1:
            return "Match 5 + 1 Lucky Star"
        elif matched_main == 5:
            return "Match 5"
        elif matched_main == 4 and matched_stars == 2:
            return "Match 4 + 2 Lucky Stars"
        elif matched_main == 4 and matched_stars == 1:
            return "Match 4 + 1 Lucky Star"
        elif matched_main == 4:
            return "Match 4"
        elif matched_main == 3 and matched_stars == 2:
            return "Match 3 + 2 Lucky Stars"
        elif matched_main == 3 and matched_stars == 1:
            return "Match 3 + 1 Lucky Star"
        elif matched_main == 3:
            return "Match 3"
        elif matched_main == 2 and matched_stars == 2:
            return "Match 2 + 2 Lucky Stars"
        elif matched_main == 2 and matched_stars == 1:
            return "Match 2 + 1 Lucky Star"
        elif matched_main == 2:
            return "Match 2"
        else:
            return "No Win"

    def simulate_single_process(self, num_simulations):
        """Simulates the EuroMillions lottery for a single process."""
        outcomes = {key: 0 for key in self.prizes.keys()}
        ticket = self.generate_ticket()
        for _ in range(num_simulations):
            draw_results = self.draw_lotto()
            outcome = self.determine_prize(ticket, draw_results)
            outcomes[outcome] += 1

        return outcomes

    @staticmethod
    def merge_results(results_list):
        """Merges the results from multiple processes."""
        final_outcomes = {key: 0 for key in MonteCarloSimulator.prizes.keys()}

        for result in results_list:
            for key in result:
                final_outcomes[key] += result[key]

        return final_outcomes

    def monte_carlo_simulation(self):
        """Runs the Monte Carlo simulation using parallel processing."""
        cpu_count = multiprocessing.cpu_count()
        pool = multiprocessing.Pool(cpu_count)
        simulations_per_process = self.simulations // cpu_count
        simulations_split = [simulations_per_process] * cpu_count
        # Handle any leftover simulations
        extra_simulations = self.simulations % cpu_count
        for i in range(extra_simulations):
            simulations_split[i] += 1

        results = pool.starmap(self.simulate_single_process, [(simulations,) for simulations in simulations_split])
        pool.close()
        pool.join()
        outcomes = self.merge_results(results)
        # Calculate probabilities
        probabilities = {key: outcomes[key] / self.simulations for key in outcomes}

        # Expected return per ticket
        expected_return = sum(probabilities[key] * self.prizes[key] for key in self.prizes)
        # Total investment, total earnings, and balance
        total_investment = self.simulations * self.ticket_cost
        total_earning = expected_return * self.simulations
        balance = total_earning - total_investment

        return {
            "probabilities": probabilities,
            "expected_return": expected_return,
            "total_investment": total_investment,
            "total_earning": total_earning,
            "balance": balance
        }


class HistoryBasedSimulator:
    MAIN_NUMBERS_POOL = range(1, 51)  # Numbers from 1 to 50
    MAIN_NUMBERS_DRAWN = 5  # Number of main numbers drawn
    LUCKY_STARS_POOL = range(1, 13)  # Lucky Stars from 1 to 12
    LUCKY_STARS_DRAWN = 2  # Number of Lucky Stars drawn

    prizes = {
        "Jackpot": 17000000,  # Starting example jackpot
        "Match 5 + 2 Lucky Stars": 17000000,  # Typically same as Jackpot
        "Match 5 + 1 Lucky Star": 500000,
        "Match 5": 100000,
        "Match 4 + 2 Lucky Stars": 5000,
        "Match 4 + 1 Lucky Star": 500,
        "Match 4": 100,
        "Match 3 + 2 Lucky Stars": 50,
        "Match 3 + 1 Lucky Star": 20,
        "Match 3": 10,
        "Match 2 + 2 Lucky Stars": 10,
        "Match 2 + 1 Lucky Star": 5,
        "Match 2": 2,
        "No Win": 0
    }

    def __init__(self, user_main_numbers, user_lucky_stars, simulations, historical_numbers, historical_lucky_stars):
        self.simulations = simulations
        self.user_main_numbers = sorted(user_main_numbers)  # Ensure the user's main numbers are sorted
        self.user_lucky_stars = sorted(user_lucky_stars)  # Ensure the user's Lucky Stars are sorted
        self.ticket_cost = 2.5
        self.historical_numbers = historical_numbers
        self.historical_lucky_stars = historical_lucky_stars

        # Calculate historical frequencies
        self.main_number_frequency, self.lucky_star_frequency = self.calculate_number_frequencies()

    def get_history(self):
        """Fetch historical EuroMillions draws from the database."""
        return self.historical_numbers, self.historical_lucky_stars

    def calculate_number_frequencies(self):
        """Calculate the frequency of each main number and Lucky Star based on historical draws."""
        main_numbers = []
        lucky_stars = []
        number, lucky = self.get_history()

        for num,star in zip(number, lucky):
            main_numbers.extend(num)
            lucky_stars.extend(star)

        main_number_freq = Counter(main_numbers)
        lucky_star_freq = Counter(lucky_stars)

        return main_number_freq, lucky_star_freq

    def weighted_draw(self):
        """Perform a weighted random draw based on historical frequency."""
        main_numbers_pool = list(self.MAIN_NUMBERS_POOL)
        lucky_stars_pool = list(self.LUCKY_STARS_POOL)

        # Calculate total draws for normalization
        total_main_draws = sum(self.main_number_frequency.values())
        total_lucky_star_draws = sum(self.lucky_star_frequency.values())

        # Create weights based on historical frequency
        main_weights = [(self.main_number_frequency.get(num, 0) / total_main_draws) for num in main_numbers_pool]
        lucky_star_weights = [(self.lucky_star_frequency.get(star, 0) / total_lucky_star_draws) for star in
                              lucky_stars_pool]

        # Perform weighted draws
        main_numbers = sorted(random.choices(main_numbers_pool, weights=main_weights, k=self.MAIN_NUMBERS_DRAWN))
        lucky_stars = sorted(random.choices(lucky_stars_pool, weights=lucky_star_weights, k=self.LUCKY_STARS_DRAWN))

        return main_numbers, lucky_stars

    def generate_ticket(self):
        """Generates a EuroMillions lottery ticket."""
        return self.user_main_numbers, self.user_lucky_stars

    def determine_prize(self, ticket, draw_results):
        """Determines the prize based on the ticket and draw results."""
        main_numbers, lucky_stars = draw_results
        matched_main = len(set(ticket[0]) & set(main_numbers))
        matched_stars = len(set(ticket[1]) & set(lucky_stars))

        if matched_main == 5 and matched_stars == 2:
            return "Jackpot"
        elif matched_main == 5 and matched_stars == 2:
            return "Match 5 + 2 Lucky Stars"
        elif matched_main == 5 and matched_stars == 1:
            return "Match 5 + 1 Lucky Star"
        elif matched_main == 5:
            return "Match 5"
        elif matched_main == 4 and matched_stars == 2:
            return "Match 4 + 2 Lucky Stars"
        elif matched_main == 4 and matched_stars == 1:
            return "Match 4 + 1 Lucky Star"
        elif matched_main == 4:
            return "Match 4"
        elif matched_main == 3 and matched_stars == 2:
            return "Match 3 + 2 Lucky Stars"
        elif matched_main == 3 and matched_stars == 1:
            return "Match 3 + 1 Lucky Star"
        elif matched_main == 3:
            return "Match 3"
        elif matched_main == 2 and matched_stars == 2:
            return "Match 2 + 2 Lucky Stars"
        elif matched_main == 2 and matched_stars == 1:
            return "Match 2 + 1 Lucky Star"
        elif matched_main == 2:
            return "Match 2"
        else:
            return "No Win"

    def simulate_single_process(self, num_simulations):
        """Simulates the EuroMillions lottery for a single process."""
        outcomes = {key: 0 for key in self.prizes.keys()}
        ticket = self.generate_ticket()

        for _ in range(num_simulations):
            draw_results = self.weighted_draw()
            outcome = self.determine_prize(ticket, draw_results)
            outcomes[outcome] += 1

        return outcomes

    @staticmethod
    def merge_results(results_list):
        """Merges the results from multiple processes."""
        final_outcomes = {key: 0 for key in HistoryBasedSimulator.prizes.keys()}

        for result in results_list:
            for key in result:
                final_outcomes[key] += result[key]

        return final_outcomes

    def monte_carlo_simulation(self):
        """Runs the Monte Carlo simulation using parallel processing."""
        cpu_count = multiprocessing.cpu_count()
        pool = multiprocessing.Pool(cpu_count)

        simulations_per_process = self.simulations // cpu_count
        simulations_split = [simulations_per_process] * cpu_count
        extra_simulations = self.simulations % cpu_count

        for i in range(extra_simulations):
            simulations_split[i] += 1

        results = pool.starmap(self.simulate_single_process, [(simulations,) for simulations in simulations_split])
        pool.close()
        pool.join()
        outcomes = self.merge_results(results)

        # Calculate probabilities
        probabilities = {key: outcomes[key] / self.simulations for key in outcomes}

        # Expected return per ticket
        expected_return = sum(probabilities[key] * self.prizes[key] for key in self.prizes)

        # Total investment, total earnings, and balance
        total_investment = self.simulations * self.ticket_cost
        total_earning = expected_return * self.simulations
        balance = total_earning - total_investment

        return {
            "probabilities": probabilities,
            "expected_return": expected_return,
            "total_investment": total_investment,
            "total_earning": total_earning,
            "balance": balance
        }
