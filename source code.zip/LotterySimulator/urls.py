from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('', lambda request: redirect('uk-lotto/')),
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('uk-lotto/', include('uk_lotto.urls')),
    path('euro-million/', include('euro_millions.urls')),
]