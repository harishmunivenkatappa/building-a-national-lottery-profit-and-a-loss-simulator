from django.urls import path
from .views import Registration, Login, Home, Logout, LotteryRule, AboutPage, SimulationHistoryView, \
    SimulationDetailView, SimulationDeleteView

urlpatterns = [
    path('register/', Registration.as_view(), name='register'),
    path('login/', Login.as_view(), name='login'),
    path('logout/', Logout.as_view(), name='logout'),
    path('home/', Home.as_view(), name='home'),
    path('rules/', LotteryRule.as_view(), name='rules'),
    path('about/', AboutPage.as_view(), name='about'),
    path('simulation_history/', SimulationHistoryView.as_view(), name='simulation_history'),
    path('simulation/<int:pk>/', SimulationDetailView.as_view(), name='simulation_detail'),
    path('simulation/<int:pk>/delete/', SimulationDeleteView.as_view(), name='simulation_delete'),

]
