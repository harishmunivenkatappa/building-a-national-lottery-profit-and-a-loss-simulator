from django.contrib.auth.models import User

from django.db import models
from django.db.models import JSONField


class SimulationHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    probabilities = JSONField()
    expected_return = models.FloatField()
    total_investment = models.FloatField()
    total_earning = models.FloatField()
    balance = models.FloatField()
    user_number = models.CharField(max_length=255)
    time_taken = models.FloatField()
    num_of_simulations = models.IntegerField()
    lottery_type = models.CharField(max_length=255, default='UK_NATIONAL')
    num_of_years = models.IntegerField(default=1)
    weekly_draws = models.IntegerField(default=1)
    algorithm = models.CharField(max_length=255, default='monte-carlo')

    def __str__(self):
        return f"LottoSimulation(id={self.id}, total_investment={self.total_investment}, balance={self.balance})"


class UKNationalDrawHistory(models.Model):
    draw_date = models.DateField()  # DrawDate
    ball_1 = models.IntegerField()  # Ball 1
    ball_2 = models.IntegerField()  # Ball 2
    ball_3 = models.IntegerField()  # Ball 3
    ball_4 = models.IntegerField()  # Ball 4
    ball_5 = models.IntegerField()  # Ball 5
    ball_6 = models.IntegerField()  # Ball 6
    bonus_ball = models.IntegerField()  # Bonus Ball
    ball_set = models.IntegerField()  # Ball Set
    machine = models.CharField(max_length=50)  # Machine
    draw_number = models.IntegerField(unique=True)  # DrawNumber

    def __str__(self):
        return f"Draw {self.draw_number} on {self.draw_date}"


class EuroMillionsDraw(models.Model):
    draw_date = models.DateField()  # DrawDate
    ball_1 = models.IntegerField()  # Ball 1
    ball_2 = models.IntegerField()  # Ball 2
    ball_3 = models.IntegerField()  # Ball 3
    ball_4 = models.IntegerField()  # Ball 4
    ball_5 = models.IntegerField()  # Ball 5
    lucky_star_1 = models.IntegerField()  # Lucky Star 1
    lucky_star_2 = models.IntegerField()  # Lucky Star 2
    uk_millionaire_maker = models.TextField()  # UK Millionaire Maker
    draw_number = models.IntegerField(unique=True)  # DrawNumber

    def __str__(self):
        return f"EuroMillions Draw {self.draw_number} on {self.draw_date}"
