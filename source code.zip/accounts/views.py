import os
import csv
from datetime import datetime

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import DetailView, DeleteView

from .forms import RegistrationForm, LoginForm

from django.contrib.auth.mixins import LoginRequiredMixin

from .models import SimulationHistory, UKNationalDrawHistory, EuroMillionsDraw


class Home(View):
    login_url = 'login'  # a Redirect to the login page if the user is not authenticated
    template_name = 'home.html'
    @staticmethod
    def import_euromillions_draws(csv_file_path):
        with open(csv_file_path, newline='') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)  # Skip the header row

            for row in reader:
                try:
                    # Parse data from CSV row
                    draw_date = datetime.strptime(row[0], "%d-%b-%Y").date()  # Convert to date
                    ball_1 = int(row[1])
                    ball_2 = int(row[2])
                    ball_3 = int(row[3])
                    ball_4 = int(row[4])
                    ball_5 = int(row[5])
                    lucky_star_1 = int(row[6])
                    lucky_star_2 = int(row[7])
                    uk_millionaire_maker = row[8]  # This can contain multiple codes
                    draw_number = int(row[9])

                    # Create and save the EuroMillionsDraw instance
                    draw = EuroMillionsDraw(
                        draw_date=draw_date,
                        ball_1=ball_1,
                        ball_2=ball_2,
                        ball_3=ball_3,
                        ball_4=ball_4,
                        ball_5=ball_5,
                        lucky_star_1=lucky_star_1,
                        lucky_star_2=lucky_star_2,
                        uk_millionaire_maker=uk_millionaire_maker,
                        draw_number=draw_number
                    )

                    draw.save()
                    print(f"Inserted draw number {draw_number}")
                except Exception as e:
                    print(f"Error processing row {row}: {e}")

    def get(self, request):
        return render(request, self.template_name)


class Registration(View):
    template_name = 'registration.html'

    def get(self, request):
        form = RegistrationForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = RegistrationForm(request.POST)
        if form.is_valid():
            # Create the user instance using form.cleaned_data
            user = form.save()
            # Automatically log the user in after registration
            login(request, user)
            return redirect('login')
        return render(request, self.template_name, {'form': form})

class Login(View):
    template_name = 'login.html'

    def get(self, request):
        form = LoginForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                # Redirect to a success page or home
                return redirect('home')
            else:
                messages.error(request, 'Invalid username or password.')

        return render(request, self.template_name, {'form': form})


class Logout(View):
    def get(self, request, *args, **kwargs):
        # Log out the user
        logout(request)
        # Optionally add a message
        messages.success(request, "You have been successfully logged out.")
        # Redirect to the desired page after logout
        return redirect(reverse_lazy('login'))  # Redirect to the login page


class LotteryRule(View):
    template_name = 'rules.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)


class AboutPage(View):
    template_name = 'about.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)

class SimulationHistoryView(View):
    template_name = 'simulation_history.html'

    def get(self, request, *args, **kwargs):
        lottery_type = request.GET.get('lottery_type', None)
        period = request.GET.get('period', None)
        weekly_draws = request.GET.get('weekly_draws', None)
        # Get all simulation history records for the logged-in user
        histories = SimulationHistory.objects.filter(user=request.user).order_by('-id')
        if lottery_type:
            histories = histories.filter(lottery_type=lottery_type)
        if period:
            histories = histories.filter(num_of_years=int(period))
        if weekly_draws:
            histories = histories.filter(weekly_draws=int(weekly_draws))

        # Implement pagination (10 items per page)
        paginator = Paginator(histories, 10)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)

        # Pass the paginated data to the template
        context = {
            'page_obj': page_obj
        }
        return render(request, self.template_name, context)


class SimulationDetailView(View):
    template_name = 'simulation_detail.html'

    def get(self, request, pk):
        # Retrieve the simulation object by primary key
        simulation = get_object_or_404(SimulationHistory, pk=pk)
        # Render the detail template with the simulation context
        context = {'simulation': simulation}
        return render(request, self.template_name, context)

class SimulationDeleteView(DeleteView):
    model = SimulationHistory
    template_name = 'simulation_confirm_delete.html'
    success_url = reverse_lazy('simulation_history')
    context_object_name = 'simulation'

    def get_object(self, queryset=None):
        # Get the simulation object by primary key (pk)
        return super().get_object(queryset=queryset)